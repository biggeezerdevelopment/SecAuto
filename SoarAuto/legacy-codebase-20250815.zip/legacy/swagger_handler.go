package main

import (
	"encoding/json"
	"fmt"
	"net/http"
)

// SwaggerUIHandler handles serving the Swagger UI documentation
type SwaggerUIHandler struct {
	openAPISpec []byte
}

// NewSwaggerUIHandler creates a new Swagger UI handler
func NewSwaggerUIHandler(serverPort string) (*SwaggerUIHandler, error) {
	// Read the OpenAPI specification with dynamic server URL
	spec, err := readOpenAPISpec(serverPort)
	if err != nil {
		return nil, fmt.Errorf("failed to read OpenAPI spec: %w", err)
	}

	return &SwaggerUIHandler{
		openAPISpec: spec,
	}, nil
}

// ServeHTTP handles HTTP requests for Swagger UI
func (h *SwaggerUIHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	// Handle API spec request
	if r.URL.Path == "/api-docs" {
		w.Header().Set("Content-Type", "application/json")
		w.Write(h.openAPISpec)
		return
	}

	// Serve the main Swagger UI page
	if r.URL.Path == "/docs" || r.URL.Path == "/docs/" {
		h.serveSwaggerUI(w, r)
		return
	}

	// Redirect root docs path
	if r.URL.Path == "/" {
		http.Redirect(w, r, "/docs", http.StatusMovedPermanently)
		return
	}

	http.NotFound(w, r)
}

// serveSwaggerUI serves the main Swagger UI page
func (h *SwaggerUIHandler) serveSwaggerUI(w http.ResponseWriter, r *http.Request) {
	// Get the current server URL from the request
	serverURL := fmt.Sprintf("http://%s", r.Host)

	html := fmt.Sprintf(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecAuto API Documentation</title>
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/swagger-ui-dist@5.9.0/swagger-ui.css" />
    <style>
        html {
            box-sizing: border-box;
            overflow: -moz-scrollbars-vertical;
            overflow-y: scroll;
        }
        *, *:before, *:after {
            box-sizing: inherit;
        }
        body {
            margin:0;
            background: #fafafa;
        }
        .swagger-ui .topbar {
            background-color: #2c3e50;
        }
        .swagger-ui .topbar .download-url-wrapper .select-label {
            color: #fff;
        }
        .swagger-ui .topbar .download-url-wrapper input[type=text] {
            border: 2px solid #34495e;
        }
        .swagger-ui .info .title {
            color: #2c3e50;
        }
        .swagger-ui .scheme-container {
            background-color: #ecf0f1;
        }
        .swagger-ui .info .title {
            font-size: 36px;
            color: #2c3e50;
        }
        .swagger-ui .info .description {
            font-size: 16px;
            line-height: 1.5;
        }
    </style>
</head>
<body>
    <div id="swagger-ui"></div>
    <script src="https://unpkg.com/swagger-ui-dist@5.9.0/swagger-ui-bundle.js"></script>
    <script src="https://unpkg.com/swagger-ui-dist@5.9.0/swagger-ui-standalone-preset.js"></script>
    <script>
        window.onload = function() {
            const ui = SwaggerUIBundle({
                url: '%s/api-docs',
                dom_id: '#swagger-ui',
                deepLinking: true,
                presets: [
                    SwaggerUIBundle.presets.apis,
                    SwaggerUIStandalonePreset
                ],
                plugins: [
                    SwaggerUIBundle.plugins.DownloadUrl
                ],
                layout: "StandaloneLayout",
                validatorUrl: null,
                onComplete: function() {
                    console.log('SecAuto API Documentation loaded successfully');
                },
                onFailure: function(data) {
                    console.error('Failed to load API documentation:', data);
                }
            });
        };
    </script>
</body>
</html>`, serverURL)

	w.Header().Set("Content-Type", "text/html")
	w.Write([]byte(html))
}

// readOpenAPISpec reads the OpenAPI specification from file
func readOpenAPISpec(serverPort string) ([]byte, error) {
	// For now, we'll return a basic spec
	// In a real implementation, you would read from openapi.yaml
	spec := map[string]interface{}{
		"openapi": "3.0.3",
		"info": map[string]interface{}{
			"title":       "SecAuto SOAR Rules Engine API",
			"description": "A powerful Security Orchestration, Automation, and Response (SOAR) rules engine API. This API provides comprehensive endpoints for job management, distributed clustering, plugin system, job scheduling, and automation workflows.",
			"version":     "1.0.0",
			"contact": map[string]interface{}{
				"name":  "SecAuto Support",
				"email": "support@secauto.com",
			},
			"license": map[string]interface{}{
				"name": "MIT",
				"url":  "https://opensource.org/licenses/MIT",
			},
		},
		"servers": []map[string]interface{}{
			{
				"url":         fmt.Sprintf("http://localhost:%s", serverPort),
				"description": "Development server",
			},
		},
		"paths": map[string]interface{}{
			"/health": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "Health Check",
					"description": "Check the health status of the SecAuto system",
					"tags":        []string{"Health"},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "System is healthy",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"status": map[string]interface{}{
												"type": "string",
												"enum": []string{"healthy", "unhealthy"},
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
											"version": map[string]interface{}{
												"type": "string",
											},
										},
									},
								},
							},
						},
					},
				},
			},
			"/playbook": map[string]interface{}{
				"post": map[string]interface{}{
					"summary":     "Execute Playbook Synchronously",
					"description": "Execute a playbook immediately and return results",
					"tags":        []string{"Playbooks"},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"type": "object",
									"properties": map[string]interface{}{
										"playbook": map[string]interface{}{
											"type":        "array",
											"items":       map[string]interface{}{"type": "object"},
											"description": "Array of playbook rules",
										},
										"context": map[string]interface{}{
											"type":        "object",
											"description": "Initial context data",
										},
										"options": map[string]interface{}{
											"type":        "object",
											"description": "Execution options",
											"properties": map[string]interface{}{
												"timeout": map[string]interface{}{
													"type":        "integer",
													"description": "Execution timeout in seconds",
												},
												"priority": map[string]interface{}{
													"type":        "string",
													"enum":        []string{"low", "normal", "high", "critical"},
													"description": "Job priority",
												},
											},
										},
									},
									"required": []string{"playbook"},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Playbook executed successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"results": map[string]interface{}{
												"type": "array",
											},
											"context": map[string]interface{}{
												"type": "object",
											},
											"timestamp": map[string]interface{}{
												"type": "string",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Invalid request",
						},
					},
				},
			},
			"/playbook/async": map[string]interface{}{
				"post": map[string]interface{}{
					"summary":     "Execute Playbook Asynchronously",
					"description": "Submit a playbook for asynchronous execution",
					"tags":        []string{"Playbooks"},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"type": "object",
									"properties": map[string]interface{}{
										"playbook": map[string]interface{}{
											"type":  "array",
											"items": map[string]interface{}{"type": "object"},
										},
										"context": map[string]interface{}{
											"type": "object",
										},
									},
									"required": []string{"playbook"},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"202": map[string]interface{}{
							"description": "Job submitted successfully",
						},
						"400": map[string]interface{}{
							"description": "Invalid request",
						},
					},
				},
			},
			"/jobs": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "List All Jobs",
					"description": "Retrieve a list of all jobs with optional filtering and pagination",
					"tags":        []string{"Jobs"},
					"parameters": []map[string]interface{}{
						{
							"name":        "status",
							"in":          "query",
							"description": "Filter by job status",
							"schema": map[string]interface{}{
								"type": "string",
								"enum": []string{"pending", "running", "completed", "failed", "cancelled"},
							},
						},
						{
							"name":        "limit",
							"in":          "query",
							"description": "Maximum number of jobs to return",
							"schema": map[string]interface{}{
								"type":    "integer",
								"default": 50,
								"maximum": 100,
							},
						},
						{
							"name":        "offset",
							"in":          "query",
							"description": "Number of jobs to skip",
							"schema": map[string]interface{}{
								"type":    "integer",
								"default": 0,
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Jobs retrieved successfully",
						},
					},
				},
			},
			"/jobs/stats": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "Job Statistics",
					"description": "Get comprehensive job statistics and metrics",
					"tags":        []string{"Jobs"},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Statistics retrieved successfully",
						},
					},
				},
			},
			"/jobs/metrics": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "Database Performance Metrics",
					"description": "Get database performance metrics and connection pool statistics",
					"tags":        []string{"Jobs"},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Metrics retrieved successfully",
						},
					},
				},
			},
			"/plugins": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "List All Plugins",
					"description": "Retrieve a list of all available plugins",
					"tags":        []string{"Plugins"},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Plugins retrieved successfully",
						},
					},
				},
			},
			"/automation": map[string]interface{}{
				"post": map[string]interface{}{
					"summary":     "Upload Automation Script",
					"description": "Upload a new automation script to the system. The script will be validated for security and stored in the automations directory.",
					"tags":        []string{"Automations"},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"multipart/form-data": map[string]interface{}{
								"schema": map[string]interface{}{
									"type": "object",
									"properties": map[string]interface{}{
										"automation": map[string]interface{}{
											"type":        "string",
											"format":      "binary",
											"description": "Python automation script file (.py)",
										},
										"metadata": map[string]interface{}{
											"type":        "string",
											"description": "JSON string containing automation metadata (optional)",
											"example":     `{"name":"script_name","venv":"Venv","return":{"result":"string"}}`,
										},
									},
									"required": []string{"automation"},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Automation uploaded successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"automation_name": map[string]interface{}{
												"type": "string",
											},
											"filename": map[string]interface{}{
												"type": "string",
											},
											"size": map[string]interface{}{
												"type": "integer",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Validation failed",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"valid": map[string]interface{}{
												"type": "boolean",
											},
											"errors": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "object",
													"properties": map[string]interface{}{
														"field": map[string]interface{}{
															"type": "string",
														},
														"message": map[string]interface{}{
															"type": "string",
														},
														"value": map[string]interface{}{
															"type": "string",
														},
													},
												},
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
					},
				},
			},
			"/playbook/upload": map[string]interface{}{
				"post": map[string]interface{}{
					"summary":     "Upload Playbook File",
					"description": "Upload a new playbook file to the system. The file will be validated for structure and stored in the playbooks directory.",
					"tags":        []string{"Playbooks"},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"multipart/form-data": map[string]interface{}{
								"schema": map[string]interface{}{
									"type": "object",
									"properties": map[string]interface{}{
										"playbook": map[string]interface{}{
											"type":        "string",
											"format":      "binary",
											"description": "Playbook JSON file (.json)",
										},
									},
									"required": []string{"playbook"},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Playbook uploaded successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"playbook_name": map[string]interface{}{
												"type": "string",
											},
											"filename": map[string]interface{}{
												"type": "string",
											},
											"size": map[string]interface{}{
												"type": "integer",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Validation failed",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"valid": map[string]interface{}{
												"type": "boolean",
											},
											"errors": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "object",
													"properties": map[string]interface{}{
														"field": map[string]interface{}{
															"type": "string",
														},
														"message": map[string]interface{}{
															"type": "string",
														},
														"value": map[string]interface{}{
															"type": "string",
														},
													},
												},
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
					},
				},
			},
			"/playbooks": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "List All Playbooks",
					"description": "Retrieve a list of all available playbooks with their metadata including rule counts, operation types, and modification dates.",
					"tags":        []string{"Playbooks"},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Playbooks retrieved successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"playbooks": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "object",
													"properties": map[string]interface{}{
														"name": map[string]interface{}{
															"type": "string",
														},
														"filename": map[string]interface{}{
															"type": "string",
														},
														"size": map[string]interface{}{
															"type": "integer",
														},
														"rule_count": map[string]interface{}{
															"type": "integer",
														},
														"operations": map[string]interface{}{
															"type": "object",
															"additionalProperties": map[string]interface{}{
																"type": "integer",
															},
														},
														"modified_at": map[string]interface{}{
															"type":   "string",
															"format": "date-time",
														},
														"is_valid": map[string]interface{}{
															"type": "boolean",
														},
													},
												},
											},
											"count": map[string]interface{}{
												"type": "integer",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"500": map[string]interface{}{
							"description": "Internal server error",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"error": map[string]interface{}{
												"type": "string",
											},
										},
									},
								},
							},
						},
					},
				},
			},
			"/automations": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "List All Automations",
					"description": "Retrieve a list of all available automation scripts with their metadata including file type, language, line count, function count, and modification dates.",
					"tags":        []string{"Automations"},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Automations retrieved successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"automations": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "object",
													"properties": map[string]interface{}{
														"name": map[string]interface{}{
															"type": "string",
														},
														"filename": map[string]interface{}{
															"type": "string",
														},
														"size": map[string]interface{}{
															"type": "integer",
														},
														"file_type": map[string]interface{}{
															"type": "string",
														},
														"language": map[string]interface{}{
															"type": "string",
														},
														"line_count": map[string]interface{}{
															"type": "integer",
														},
														"function_count": map[string]interface{}{
															"type": "integer",
														},
														"import_count": map[string]interface{}{
															"type": "integer",
														},
														"modified_at": map[string]interface{}{
															"type":   "string",
															"format": "date-time",
														},
														"is_valid": map[string]interface{}{
															"type": "boolean",
														},
													},
												},
											},
											"count": map[string]interface{}{
												"type": "integer",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"500": map[string]interface{}{
							"description": "Internal server error",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"error": map[string]interface{}{
												"type": "string",
											},
										},
									},
								},
							},
						},
					},
				},
			},
			"/automation/{name}": map[string]interface{}{
				"delete": map[string]interface{}{
					"summary":     "Delete Automation",
					"description": "Delete an automation script. If the automation is used by any playbooks, the deletion will be blocked and the dependent playbooks will be listed.",
					"tags":        []string{"Automations"},
					"parameters": []map[string]interface{}{
						{
							"name":        "name",
							"in":          "path",
							"required":    true,
							"description": "Name of the automation to delete",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Automation deleted successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"automation_name": map[string]interface{}{
												"type": "string",
											},
											"dependencies": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "string",
												},
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"409": map[string]interface{}{
							"description": "Automation cannot be deleted - dependencies exist",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"automation_name": map[string]interface{}{
												"type": "string",
											},
											"dependencies": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "string",
												},
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"404": map[string]interface{}{
							"description": "Automation not found",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"error": map[string]interface{}{
												"type": "string",
											},
										},
									},
								},
							},
						},
					},
				},
			},
			"/automation/metadata": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "List All Automation Metadata",
					"description": "Retrieve metadata for all automation scripts including virtual environment paths and return value specifications.",
					"tags":        []string{"Automations"},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Metadata retrieved successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"$ref": "#/components/schemas/AutomationMetadataResponse",
									},
								},
							},
						},
						"500": map[string]interface{}{
							"description": "Internal server error",
						},
					},
				},
				"post": map[string]interface{}{
					"summary":     "Create Automation Metadata",
					"description": "Create new metadata for an automation script.",
					"tags":        []string{"Automations"},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"$ref": "#/components/schemas/AutomationMetadata",
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Metadata created successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"$ref": "#/components/schemas/AutomationMetadataResponse",
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Invalid request body",
						},
						"500": map[string]interface{}{
							"description": "Internal server error",
						},
					},
				},
			},
			"/automation/metadata/{name}": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "Get Automation Metadata",
					"description": "Retrieve metadata for a specific automation script.",
					"tags":        []string{"Automations"},
					"parameters": []map[string]interface{}{
						{
							"name":        "name",
							"in":          "path",
							"required":    true,
							"description": "Name of the automation",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Metadata retrieved successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"$ref": "#/components/schemas/AutomationMetadataResponse",
									},
								},
							},
						},
						"404": map[string]interface{}{
							"description": "Metadata not found",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"$ref": "#/components/schemas/AutomationMetadataResponse",
									},
								},
							},
						},
						"500": map[string]interface{}{
							"description": "Internal server error",
						},
					},
				},
				"put": map[string]interface{}{
					"summary":     "Update Automation Metadata",
					"description": "Update metadata for a specific automation script.",
					"tags":        []string{"Automations"},
					"parameters": []map[string]interface{}{
						{
							"name":        "name",
							"in":          "path",
							"required":    true,
							"description": "Name of the automation",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"$ref": "#/components/schemas/AutomationMetadata",
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Metadata updated successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"$ref": "#/components/schemas/AutomationMetadataResponse",
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Invalid request body",
						},
						"500": map[string]interface{}{
							"description": "Internal server error",
						},
					},
				},
				"delete": map[string]interface{}{
					"summary":     "Delete Automation Metadata",
					"description": "Delete metadata for a specific automation script.",
					"tags":        []string{"Automations"},
					"parameters": []map[string]interface{}{
						{
							"name":        "name",
							"in":          "path",
							"required":    true,
							"description": "Name of the automation",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Metadata deleted successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"$ref": "#/components/schemas/AutomationMetadataResponse",
									},
								},
							},
						},
						"404": map[string]interface{}{
							"description": "Metadata not found",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"$ref": "#/components/schemas/AutomationMetadataResponse",
									},
								},
							},
						},
						"500": map[string]interface{}{
							"description": "Internal server error",
						},
					},
				},
			},
			"/playbook/{name}": map[string]interface{}{
				"delete": map[string]interface{}{
					"summary":     "Delete Playbook",
					"description": "Delete a playbook file from the system.",
					"tags":        []string{"Playbooks"},
					"parameters": []map[string]interface{}{
						{
							"name":        "name",
							"in":          "path",
							"required":    true,
							"description": "Name of the playbook to delete",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Playbook deleted successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"playbook_name": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"404": map[string]interface{}{
							"description": "Playbook not found",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"error": map[string]interface{}{
												"type": "string",
											},
										},
									},
								},
							},
						},
					},
				},
			},
			"/plugin/{type}/{name}": map[string]interface{}{
				"delete": map[string]interface{}{
					"summary":     "Delete Plugin",
					"description": "Delete a plugin file from the system for a specific platform type.",
					"tags":        []string{"Plugins"},
					"parameters": []map[string]interface{}{
						{
							"name":        "type",
							"in":          "path",
							"required":    true,
							"description": "Plugin type (linux, windows, python, go)",
							"schema": map[string]interface{}{
								"type": "string",
								"enum": []string{"linux", "windows", "python", "go"},
							},
						},
						{
							"name":        "name",
							"in":          "path",
							"required":    true,
							"description": "Name of the plugin to delete",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Plugin deleted successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"plugin_name": map[string]interface{}{
												"type": "string",
											},
											"plugin_type": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"404": map[string]interface{}{
							"description": "Plugin not found",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"error": map[string]interface{}{
												"type": "string",
											},
										},
									},
								},
							},
						},
					},
				},
			},
			"/cluster": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "Get Cluster Information",
					"description": "Retrieve information about the distributed cluster",
					"tags":        []string{"Cluster"},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Cluster information retrieved successfully",
						},
					},
				},
			},
			"/schedules": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "List All Schedules",
					"description": "Retrieve a list of all job schedules",
					"tags":        []string{"Schedules"},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Schedules retrieved successfully",
						},
					},
				},
				"post": map[string]interface{}{
					"summary":     "Create New Schedule",
					"description": "Create a new job schedule",
					"tags":        []string{"Schedules"},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"type": "object",
									"properties": map[string]interface{}{
										"name": map[string]interface{}{
											"type":        "string",
											"description": "Schedule name",
										},
										"description": map[string]interface{}{
											"type":        "string",
											"description": "Schedule description",
										},
										"schedule_type": map[string]interface{}{
											"type":        "string",
											"enum":        []string{"cron", "interval", "one_time"},
											"description": "Type of schedule",
										},
										"cron_expression": map[string]interface{}{
											"type":        "string",
											"description": "Cron expression (for cron type)",
										},
										"interval_seconds": map[string]interface{}{
											"type":        "integer",
											"description": "Interval in seconds (for interval type)",
										},
										"playbook": map[string]interface{}{
											"type":        "array",
											"items":       map[string]interface{}{"type": "object"},
											"description": "Playbook rules to execute",
										},
										"context": map[string]interface{}{
											"type":        "object",
											"description": "Initial context for the job",
										},
										"status": map[string]interface{}{
											"type":        "string",
											"enum":        []string{"active", "inactive"},
											"description": "Schedule status",
										},
									},
									"required": []string{"name", "schedule_type", "playbook"},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"201": map[string]interface{}{
							"description": "Schedule created successfully",
						},
						"400": map[string]interface{}{
							"description": "Invalid schedule configuration",
						},
					},
				},
			},
			"/webhooks": map[string]interface{}{
				"post": map[string]interface{}{
					"summary":     "Configure Webhooks",
					"description": "Configure webhook notifications for job events",
					"tags":        []string{"Webhooks"},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"type": "object",
									"properties": map[string]interface{}{
										"url": map[string]interface{}{
											"type":        "string",
											"format":      "uri",
											"description": "Webhook URL",
										},
										"events": map[string]interface{}{
											"type": "array",
											"items": map[string]interface{}{
												"type": "string",
												"enum": []string{"job_started", "job_completed", "job_failed", "job_cancelled"},
											},
											"description": "Events to trigger webhook",
										},
										"headers": map[string]interface{}{
											"type":        "object",
											"description": "Custom headers",
										},
										"timeout": map[string]interface{}{
											"type":        "integer",
											"description": "Request timeout in seconds",
										},
										"retry_count": map[string]interface{}{
											"type":        "integer",
											"description": "Number of retry attempts",
										},
									},
									"required": []string{"url", "events"},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"201": map[string]interface{}{
							"description": "Webhook configured successfully",
						},
						"400": map[string]interface{}{
							"description": "Invalid webhook configuration",
						},
					},
				},
			},
			"/validate": map[string]interface{}{
				"post": map[string]interface{}{
					"summary":     "Validate Playbook/Context",
					"description": "Validate a playbook and context without executing",
					"tags":        []string{"Validation"},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"type": "object",
									"properties": map[string]interface{}{
										"playbook": map[string]interface{}{
											"type":        "array",
											"items":       map[string]interface{}{"type": "object"},
											"description": "Playbook rules to validate",
										},
										"context": map[string]interface{}{
											"type":        "object",
											"description": "Context to validate",
										},
									},
									"required": []string{"playbook"},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Validation completed successfully",
						},
						"400": map[string]interface{}{
							"description": "Validation failed",
						},
					},
				},
			},
			"/plugin/{type}": map[string]interface{}{
				"post": map[string]interface{}{
					"summary":     "Upload Plugin File",
					"description": "Upload a new plugin file to the system for a specific platform type (linux, windows, python, go). The file will be validated and stored in the appropriate plugins directory.",
					"tags":        []string{"Plugins"},
					"parameters": []map[string]interface{}{
						{
							"name":        "type",
							"in":          "path",
							"required":    true,
							"description": "Plugin type (linux, windows, python, go)",
							"schema": map[string]interface{}{
								"type": "string",
								"enum": []string{"linux", "windows", "python", "go"},
							},
						},
					},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"multipart/form-data": map[string]interface{}{
								"schema": map[string]interface{}{
									"type": "object",
									"properties": map[string]interface{}{
										"plugin": map[string]interface{}{
											"type":        "string",
											"format":      "binary",
											"description": "Plugin file (binary or script)",
										},
									},
									"required": []string{"plugin"},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Plugin uploaded successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"plugin_name": map[string]interface{}{
												"type": "string",
											},
											"plugin_type": map[string]interface{}{
												"type": "string",
											},
											"filename": map[string]interface{}{
												"type": "string",
											},
											"size": map[string]interface{}{
												"type": "integer",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Validation failed",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"valid": map[string]interface{}{
												"type": "boolean",
											},
											"errors": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "object",
													"properties": map[string]interface{}{
														"field": map[string]interface{}{
															"type": "string",
														},
														"message": map[string]interface{}{
															"type": "string",
														},
														"value": map[string]interface{}{
															"type": "string",
														},
													},
												},
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
					},
				},
			},
			"/integrations": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "List All Integrations",
					"description": "Retrieve a list of all configured integrations with their status and basic information",
					"tags":        []string{"Integrations"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Integrations retrieved successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"integrations": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "object",
													"properties": map[string]interface{}{
														"name": map[string]interface{}{
															"type": "string",
														},
														"type": map[string]interface{}{
															"type": "string",
														},
														"enabled": map[string]interface{}{
															"type": "boolean",
														},
														"description": map[string]interface{}{
															"type": "string",
														},
														"version": map[string]interface{}{
															"type": "string",
														},
														"created_at": map[string]interface{}{
															"type":   "string",
															"format": "date-time",
														},
														"updated_at": map[string]interface{}{
															"type":   "string",
															"format": "date-time",
														},
													},
												},
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
					},
				},
				"post": map[string]interface{}{
					"summary":     "Create Integration",
					"description": "Create a new integration configuration with encrypted credentials",
					"tags":        []string{"Integrations"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"type": "object",
									"properties": map[string]interface{}{
										"name": map[string]interface{}{
											"type":        "string",
											"description": "Integration name",
										},
										"type": map[string]interface{}{
											"type":        "string",
											"description": "Integration type (virustotal, slack, email, etc.)",
										},
										"url": map[string]interface{}{
											"type":        "string",
											"description": "Integration API URL",
										},
										"apikey": map[string]interface{}{
											"type":        "string",
											"description": "API key (will be encrypted)",
										},
										"username": map[string]interface{}{
											"type":        "string",
											"description": "Username for authentication",
										},
										"password": map[string]interface{}{
											"type":        "string",
											"description": "Password (will be encrypted)",
										},
										"token": map[string]interface{}{
											"type":        "string",
											"description": "Access token (will be encrypted)",
										},
										"secret": map[string]interface{}{
											"type":        "string",
											"description": "Secret key (will be encrypted)",
										},
										"enabled": map[string]interface{}{
											"type":        "boolean",
											"description": "Whether the integration is enabled",
										},
										"description": map[string]interface{}{
											"type":        "string",
											"description": "Integration description",
										},
										"version": map[string]interface{}{
											"type":        "string",
											"description": "Integration version",
										},
										"settings": map[string]interface{}{
											"type":        "object",
											"description": "Additional configuration settings",
										},
									},
									"required": []string{"name", "type"},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Integration created successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"integration": map[string]interface{}{
												"type": "object",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Validation failed",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
					},
				},
			},
			"/integrations/upload": map[string]interface{}{
				"post": map[string]interface{}{
					"summary":     "Upload Integration File",
					"description": "Upload a Python integration module file to the integrations directory. The file will be validated and stored for use in automations.",
					"tags":        []string{"Integrations"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"multipart/form-data": map[string]interface{}{
								"schema": map[string]interface{}{
									"type": "object",
									"properties": map[string]interface{}{
										"integration": map[string]interface{}{
											"type":        "string",
											"format":      "binary",
											"description": "Python integration file (.py)",
										},
									},
									"required": []string{"integration"},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Integration uploaded successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"integration_name": map[string]interface{}{
												"type": "string",
											},
											"filename": map[string]interface{}{
												"type": "string",
											},
											"size": map[string]interface{}{
												"type": "integer",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Validation failed",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"valid": map[string]interface{}{
												"type": "boolean",
											},
											"errors": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "object",
													"properties": map[string]interface{}{
														"field": map[string]interface{}{
															"type": "string",
														},
														"message": map[string]interface{}{
															"type": "string",
														},
														"value": map[string]interface{}{
															"type": "string",
														},
													},
												},
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
					},
				},
			},
			"/integrations/delete/{name}": map[string]interface{}{
				"delete": map[string]interface{}{
					"summary":     "Delete Integration File",
					"description": "Delete a Python integration module file from the integrations directory. Checks for dependencies in automations before deletion.",
					"tags":        []string{"Integrations"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "name",
							"in":          "path",
							"required":    true,
							"description": "Integration name (e.g., 'virustotal', 'slack')",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Integration deleted successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"integration_name": map[string]interface{}{
												"type": "string",
											},
											"dependencies": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "string",
												},
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Invalid integration name",
						},
						"404": map[string]interface{}{
							"description": "Integration not found",
						},
						"409": map[string]interface{}{
							"description": "Cannot delete integration - it is used by automations",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"integration_name": map[string]interface{}{
												"type": "string",
											},
											"dependencies": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "string",
												},
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
					},
				},
			},
			"/integrations/{name}": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "Get Integration",
					"description": "Retrieve a specific integration configuration by name",
					"tags":        []string{"Integrations"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "name",
							"in":          "path",
							"required":    true,
							"description": "Integration name (e.g., 'virustotal', 'slack')",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Integration retrieved successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"integration": map[string]interface{}{
												"type": "object",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"404": map[string]interface{}{
							"description": "Integration not found",
						},
					},
				},
				"put": map[string]interface{}{
					"summary":     "Update Integration",
					"description": "Update an existing integration configuration by name",
					"tags":        []string{"Integrations"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "name",
							"in":          "path",
							"required":    true,
							"description": "Integration name (e.g., 'virustotal', 'slack')",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"type": "object",
									"properties": map[string]interface{}{
										"name": map[string]interface{}{
											"type":        "string",
											"description": "Integration name (optional, will use path parameter if not provided)",
										},
										"type": map[string]interface{}{
											"type":        "string",
											"description": "Integration type",
										},
										"url": map[string]interface{}{
											"type":        "string",
											"description": "Integration API URL",
										},
										"apikey": map[string]interface{}{
											"type":        "string",
											"description": "API key (will be encrypted)",
										},
										"username": map[string]interface{}{
											"type":        "string",
											"description": "Username for authentication",
										},
										"password": map[string]interface{}{
											"type":        "string",
											"description": "Password (will be encrypted)",
										},
										"token": map[string]interface{}{
											"type":        "string",
											"description": "Access token (will be encrypted)",
										},
										"secret": map[string]interface{}{
											"type":        "string",
											"description": "Secret key (will be encrypted)",
										},
										"enabled": map[string]interface{}{
											"type":        "boolean",
											"description": "Whether the integration is enabled",
										},
										"description": map[string]interface{}{
											"type":        "string",
											"description": "Integration description",
										},
										"version": map[string]interface{}{
											"type":        "string",
											"description": "Integration version",
										},
										"settings": map[string]interface{}{
											"type":        "object",
											"description": "Additional configuration settings",
										},
									},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Integration updated successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"integration": map[string]interface{}{
												"type": "object",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Validation failed",
						},
						"404": map[string]interface{}{
							"description": "Integration not found",
						},
					},
				},
				"delete": map[string]interface{}{
					"summary":     "Delete Integration",
					"description": "Delete an integration configuration by name",
					"tags":        []string{"Integrations"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "name",
							"in":          "path",
							"required":    true,
							"description": "Integration name (e.g., 'virustotal', 'slack')",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Integration deleted successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"404": map[string]interface{}{
							"description": "Integration not found",
						},
					},
				},
			},
			"/clients/{client}/integrations": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "List Client Integrations",
					"description": "Retrieve all integration configurations for a specific client",
					"tags":        []string{"Client Integrations"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "client",
							"in":          "path",
							"required":    true,
							"description": "Client name (e.g., 'acme-corp', 'client-b')",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Client integrations retrieved successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"integrations": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "object",
													"properties": map[string]interface{}{
														"name": map[string]interface{}{
															"type": "string",
														},
														"type": map[string]interface{}{
															"type": "string",
														},
														"client": map[string]interface{}{
															"type": "string",
														},
														"enabled": map[string]interface{}{
															"type": "boolean",
														},
														"description": map[string]interface{}{
															"type": "string",
														},
														"version": map[string]interface{}{
															"type": "string",
														},
														"created_at": map[string]interface{}{
															"type":   "string",
															"format": "date-time",
														},
														"updated_at": map[string]interface{}{
															"type":   "string",
															"format": "date-time",
														},
													},
												},
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Invalid client name",
						},
					},
				},
			},
			"/clients/{client}/integrations/{integration}": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "Get Client Integration",
					"description": "Retrieve a specific client integration configuration",
					"tags":        []string{"Client Integrations"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "client",
							"in":          "path",
							"required":    true,
							"description": "Client name (e.g., 'acme-corp', 'client-b')",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
						{
							"name":        "integration",
							"in":          "path",
							"required":    true,
							"description": "Integration name (e.g., 'virustotal', 'slack')",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Client integration retrieved successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"integration": map[string]interface{}{
												"type": "object",
												"properties": map[string]interface{}{
													"name": map[string]interface{}{
														"type": "string",
													},
													"type": map[string]interface{}{
														"type": "string",
													},
													"client": map[string]interface{}{
														"type": "string",
													},
													"url": map[string]interface{}{
														"type": "string",
													},
													"apikey": map[string]interface{}{
														"type": "string",
													},
													"enabled": map[string]interface{}{
														"type": "boolean",
													},
													"description": map[string]interface{}{
														"type": "string",
													},
													"version": map[string]interface{}{
														"type": "string",
													},
													"settings": map[string]interface{}{
														"type": "object",
													},
													"created_at": map[string]interface{}{
														"type":   "string",
														"format": "date-time",
													},
													"updated_at": map[string]interface{}{
														"type":   "string",
														"format": "date-time",
													},
												},
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"404": map[string]interface{}{
							"description": "Client integration not found",
						},
					},
				},
				"post": map[string]interface{}{
					"summary":     "Create Client Integration",
					"description": "Create a new client-specific integration configuration with encrypted credentials",
					"tags":        []string{"Client Integrations"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "client",
							"in":          "path",
							"required":    true,
							"description": "Client name (e.g., 'acme-corp', 'client-b')",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
						{
							"name":        "integration",
							"in":          "path",
							"required":    true,
							"description": "Integration name (e.g., 'virustotal', 'slack')",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"type": "object",
									"properties": map[string]interface{}{
										"name": map[string]interface{}{
											"type":        "string",
											"description": "Integration name (optional, will use path parameter)",
										},
										"type": map[string]interface{}{
											"type":        "string",
											"description": "Integration type (virustotal, slack, email, etc.)",
										},
										"url": map[string]interface{}{
											"type":        "string",
											"description": "Integration API URL",
										},
										"apikey": map[string]interface{}{
											"type":        "string",
											"description": "API key (will be encrypted)",
										},
										"username": map[string]interface{}{
											"type":        "string",
											"description": "Username for authentication",
										},
										"password": map[string]interface{}{
											"type":        "string",
											"description": "Password (will be encrypted)",
										},
										"token": map[string]interface{}{
											"type":        "string",
											"description": "Access token (will be encrypted)",
										},
										"secret": map[string]interface{}{
											"type":        "string",
											"description": "Secret key (will be encrypted)",
										},
										"enabled": map[string]interface{}{
											"type":        "boolean",
											"description": "Whether the integration is enabled",
										},
										"description": map[string]interface{}{
											"type":        "string",
											"description": "Integration description",
										},
										"version": map[string]interface{}{
											"type":        "string",
											"description": "Integration version",
										},
										"settings": map[string]interface{}{
											"type":        "object",
											"description": "Additional configuration settings",
										},
									},
									"required": []string{"type"},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Client integration created successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"integration": map[string]interface{}{
												"type": "object",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Validation failed",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
					},
				},
				"put": map[string]interface{}{
					"summary":     "Update Client Integration",
					"description": "Update an existing client-specific integration configuration",
					"tags":        []string{"Client Integrations"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "client",
							"in":          "path",
							"required":    true,
							"description": "Client name (e.g., 'acme-corp', 'client-b')",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
						{
							"name":        "integration",
							"in":          "path",
							"required":    true,
							"description": "Integration name (e.g., 'virustotal', 'slack')",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"type": "object",
									"properties": map[string]interface{}{
										"name": map[string]interface{}{
											"type":        "string",
											"description": "Integration name (optional, will use path parameter)",
										},
										"type": map[string]interface{}{
											"type":        "string",
											"description": "Integration type",
										},
										"url": map[string]interface{}{
											"type":        "string",
											"description": "Integration API URL",
										},
										"apikey": map[string]interface{}{
											"type":        "string",
											"description": "API key (will be encrypted)",
										},
										"username": map[string]interface{}{
											"type":        "string",
											"description": "Username for authentication",
										},
										"password": map[string]interface{}{
											"type":        "string",
											"description": "Password (will be encrypted)",
										},
										"token": map[string]interface{}{
											"type":        "string",
											"description": "Access token (will be encrypted)",
										},
										"secret": map[string]interface{}{
											"type":        "string",
											"description": "Secret key (will be encrypted)",
										},
										"enabled": map[string]interface{}{
											"type":        "boolean",
											"description": "Whether the integration is enabled",
										},
										"description": map[string]interface{}{
											"type":        "string",
											"description": "Integration description",
										},
										"version": map[string]interface{}{
											"type":        "string",
											"description": "Integration version",
										},
										"settings": map[string]interface{}{
											"type":        "object",
											"description": "Additional configuration settings",
										},
									},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Client integration updated successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"integration": map[string]interface{}{
												"type": "object",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Validation failed",
						},
						"404": map[string]interface{}{
							"description": "Client integration not found",
						},
					},
				},
				"delete": map[string]interface{}{
					"summary":     "Delete Client Integration",
					"description": "Delete a client-specific integration configuration",
					"tags":        []string{"Client Integrations"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "client",
							"in":          "path",
							"required":    true,
							"description": "Client name (e.g., 'acme-corp', 'client-b')",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
						{
							"name":        "integration",
							"in":          "path",
							"required":    true,
							"description": "Integration name (e.g., 'virustotal', 'slack')",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Client integration deleted successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"404": map[string]interface{}{
							"description": "Client integration not found",
						},
					},
				},
			},
			"/cache": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "Get Cache Information",
					"description": "Get general information about the Redis cache system and available operations.",
					"tags":        []string{"Cache"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Cache information retrieved successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"operations": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "object",
													"properties": map[string]interface{}{
														"method": map[string]interface{}{
															"type": "string",
														},
														"path": map[string]interface{}{
															"type": "string",
														},
														"description": map[string]interface{}{
															"type": "string",
														},
													},
												},
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
					},
				},
			},
			"/cache/{key}": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "Get Cache Value",
					"description": "Retrieve a value from Redis cache by key. Supports automatic JSON deserialization for complex data types.",
					"tags":        []string{"Cache"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "key",
							"in":          "path",
							"required":    true,
							"description": "Cache key to retrieve",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Cache value retrieved successfully or key not found",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"key": map[string]interface{}{
												"type": "string",
											},
											"value": map[string]interface{}{
												"description": "The cached value (any JSON type)",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"error_message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"500": map[string]interface{}{
							"description": "Redis connection error",
						},
					},
				},
				"post": map[string]interface{}{
					"summary":     "Set Cache Value",
					"description": "Store a value in Redis cache with the specified key. Supports all JSON data types including strings, numbers, objects, and arrays.",
					"tags":        []string{"Cache"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "key",
							"in":          "path",
							"required":    true,
							"description": "Cache key to set",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"requestBody": map[string]interface{}{
						"required": true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"type":     "object",
									"required": []string{"value"},
									"properties": map[string]interface{}{
										"value": map[string]interface{}{
											"description": "The value to cache (any JSON type)",
											"oneOf": []map[string]interface{}{
												{"type": "string"},
												{"type": "number"},
												{"type": "boolean"},
												{"type": "object"},
												{"type": "array"},
											},
										},
									},
								},
								"examples": map[string]interface{}{
									"string_value": map[string]interface{}{
										"summary": "String Value",
										"value": map[string]interface{}{
											"value": "Hello World",
										},
									},
									"object_value": map[string]interface{}{
										"summary": "Object Value",
										"value": map[string]interface{}{
											"value": map[string]interface{}{
												"user_id":  123,
												"username": "john_doe",
												"active":   true,
												"metadata": map[string]interface{}{"role": "admin"},
											},
										},
									},
									"array_value": map[string]interface{}{
										"summary": "Array Value",
										"value": map[string]interface{}{
											"value": []interface{}{
												map[string]interface{}{"id": 1, "name": "Item 1"},
												map[string]interface{}{"id": 2, "name": "Item 2"},
											},
										},
									},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Value stored successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"key": map[string]interface{}{
												"type": "string",
											},
											"value": map[string]interface{}{
												"description": "The stored value",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Invalid request body or missing value",
						},
						"500": map[string]interface{}{
							"description": "Redis connection error",
						},
					},
				},
				"delete": map[string]interface{}{
					"summary":     "Delete Cache Value",
					"description": "Remove a value from Redis cache by key.",
					"tags":        []string{"Cache"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "key",
							"in":          "path",
							"required":    true,
							"description": "Cache key to delete",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Delete operation completed (success or key not found)",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"key": map[string]interface{}{
												"type": "string",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"error_message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"500": map[string]interface{}{
							"description": "Redis connection error",
						},
					},
				},
			},
			"/lists/{list_name}": map[string]interface{}{
				"get": map[string]interface{}{
					"summary":     "Get List Items",
					"description": "Retrieve all items from a Redis list.",
					"tags":        []string{"Lists"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "list_name",
							"in":          "path",
							"required":    true,
							"description": "Name of the Redis list",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "List retrieved successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"list_name": map[string]interface{}{
												"type": "string",
											},
											"items": map[string]interface{}{
												"type": "array",
												"items": map[string]interface{}{
													"type": "object",
												},
											},
											"count": map[string]interface{}{
												"type": "integer",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"500": map[string]interface{}{
							"description": "Redis connection error",
						},
					},
				},
				"delete": map[string]interface{}{
					"summary":     "Delete List",
					"description": "Delete an entire Redis list.",
					"tags":        []string{"Lists"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "list_name",
							"in":          "path",
							"required":    true,
							"description": "Name of the Redis list to delete",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "List deletion completed",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"list_name": map[string]interface{}{
												"type": "string",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"error_message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"500": map[string]interface{}{
							"description": "Redis connection error",
						},
					},
				},
			},
			"/lists/{list_name}/items": map[string]interface{}{
				"post": map[string]interface{}{
					"summary":     "Add Items to List",
					"description": "Add items to a Redis list. Items can be added to the left (beginning) or right (end) of the list. Duplicate items are automatically detected and skipped.",
					"tags":        []string{"Lists"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "list_name",
							"in":          "path",
							"required":    true,
							"description": "Name of the Redis list",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"requestBody": map[string]interface{}{
						"description": "Items to add to the list",
						"required":    true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"type":     "object",
									"required": []string{"items"},
									"properties": map[string]interface{}{
										"items": map[string]interface{}{
											"type":        "array",
											"description": "Array of items to add to the list",
											"items": map[string]interface{}{
												"type": "object",
											},
											"minItems": 1,
										},
										"position": map[string]interface{}{
											"type":        "string",
											"enum":        []string{"left", "right"},
											"default":     "right",
											"description": "Position to add items - 'left' (beginning) or 'right' (end)",
										},
									},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Items added successfully",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"list_name": map[string]interface{}{
												"type": "string",
											},
											"count": map[string]interface{}{
												"type":        "integer",
												"description": "Total number of items in list after addition",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Invalid request body or parameters",
						},
						"500": map[string]interface{}{
							"description": "Redis connection error",
						},
					},
				},
				"delete": map[string]interface{}{
					"summary":     "Remove Items from List",
					"description": "Remove specific items from a Redis list. You can specify how many occurrences of each item to remove.",
					"tags":        []string{"Lists"},
					"security":    []map[string]interface{}{{"ApiKeyAuth": []string{}}},
					"parameters": []map[string]interface{}{
						{
							"name":        "list_name",
							"in":          "path",
							"required":    true,
							"description": "Name of the Redis list",
							"schema": map[string]interface{}{
								"type": "string",
							},
						},
					},
					"requestBody": map[string]interface{}{
						"description": "Items to remove from the list",
						"required":    true,
						"content": map[string]interface{}{
							"application/json": map[string]interface{}{
								"schema": map[string]interface{}{
									"type":     "object",
									"required": []string{"items"},
									"properties": map[string]interface{}{
										"items": map[string]interface{}{
											"type":        "array",
											"description": "Array of items to remove from the list",
											"items": map[string]interface{}{
												"type": "object",
											},
											"minItems": 1,
										},
										"count": map[string]interface{}{
											"type":        "integer",
											"default":     1,
											"minimum":     1,
											"description": "Number of occurrences of each item to remove",
										},
									},
								},
							},
						},
					},
					"responses": map[string]interface{}{
						"200": map[string]interface{}{
							"description": "Items removal completed",
							"content": map[string]interface{}{
								"application/json": map[string]interface{}{
									"schema": map[string]interface{}{
										"type": "object",
										"properties": map[string]interface{}{
											"success": map[string]interface{}{
												"type": "boolean",
											},
											"list_name": map[string]interface{}{
												"type": "string",
											},
											"count": map[string]interface{}{
												"type":        "integer",
												"description": "Number of items actually removed",
											},
											"message": map[string]interface{}{
												"type": "string",
											},
											"timestamp": map[string]interface{}{
												"type":   "string",
												"format": "date-time",
											},
										},
									},
								},
							},
						},
						"400": map[string]interface{}{
							"description": "Invalid request body or parameters",
						},
						"500": map[string]interface{}{
							"description": "Redis connection error",
						},
					},
				},
			},
		},
		"components": map[string]interface{}{
			"securitySchemes": map[string]interface{}{
				"ApiKeyAuth": map[string]interface{}{
					"type":        "apiKey",
					"in":          "header",
					"name":        "X-API-Key",
					"description": "API key for authentication",
				},
			},
			"schemas": map[string]interface{}{
				"AutomationMetadata": map[string]interface{}{
					"type": "object",
					"properties": map[string]interface{}{
						"name": map[string]interface{}{
							"type":        "string",
							"description": "Name of the automation script",
							"example":     "addclient",
						},
						"venv": map[string]interface{}{
							"type":        "string",
							"description": "Path to the Python virtual environment",
							"example":     "Venv",
						},
						"description": map[string]interface{}{
							"type":        "string",
							"description": "Human-readable description of what the automation does",
							"example":     "Adds a new client to the system and returns client information",
						},
						"return": map[string]interface{}{
							"type":        "object",
							"description": "Object describing expected return values and their types",
							"additionalProperties": map[string]interface{}{
								"type": "string",
							},
							"example": map[string]interface{}{
								"clientname": "string",
								"status":     "string",
							},
						},
					},
					"required": []string{"name", "venv", "return"},
				},
				"AutomationMetadataResponse": map[string]interface{}{
					"type": "object",
					"properties": map[string]interface{}{
						"success": map[string]interface{}{
							"type":        "boolean",
							"description": "Whether the operation was successful",
						},
						"message": map[string]interface{}{
							"type":        "string",
							"description": "Response message",
						},
						"metadata": map[string]interface{}{
							"type":        "array",
							"description": "Array of automation metadata",
							"items": map[string]interface{}{
								"$ref": "#/components/schemas/AutomationMetadata",
							},
						},
						"timestamp": map[string]interface{}{
							"type":        "string",
							"format":      "date-time",
							"description": "ISO 8601 timestamp of the response",
						},
					},
					"required": []string{"success", "message", "timestamp"},
				},
			},
		},
		"security": []map[string]interface{}{
			{"ApiKeyAuth": []string{}},
		},
		"tags": []map[string]interface{}{
			{
				"name":        "Health",
				"description": "Health monitoring endpoints",
			},
			{
				"name":        "Playbooks",
				"description": "Playbook execution endpoints",
			},
			{
				"name":        "Jobs",
				"description": "Job management endpoints",
			},
			{
				"name":        "Plugins",
				"description": "Plugin system endpoints",
			},
			{
				"name":        "Cluster",
				"description": "Distributed cluster endpoints",
			},
			{
				"name":        "Schedules",
				"description": "Job scheduling endpoints",
			},
			{
				"name":        "Webhooks",
				"description": "Webhook configuration endpoints",
			},
			{
				"name":        "Validation",
				"description": "Validation endpoints",
			},
			{
				"name":        "Automations",
				"description": "Automation script management endpoints",
			},
			{
				"name":        "Integrations",
				"description": "Integration management endpoints",
			},
			{
				"name":        "Cache",
				"description": "Redis cache management endpoints",
			},
			{
				"name":        "Lists",
				"description": "Redis list management endpoints",
			},
			{
				"name":        "Client Integrations",
				"description": "Client-specific integration management endpoints",
			},
		},
	}

	return json.Marshal(spec)
}
